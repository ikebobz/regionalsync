package application;

public interface DAO {
	public static final String DB_URL = "jdbc:postgresql://localhost/lp_mayfair";
	public static final String USER = "postgres";
	public static final String PASS = "lamis";

}
